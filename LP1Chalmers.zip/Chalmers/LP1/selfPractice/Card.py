class Card:
    def __init__(self, rank, suit):
        self.list = ["Ace", 2, 3, 4, 5, 6, 7, 8, 9, 10, "Jack", "Queen", "King"]
        self.rank = rank
        self.suit = suit
        self.type = {"d":"Diamonds", "c":"Clubs", "h":"Hearts", "s":"Spades"}
        self.val = 0
    def getRank(self):
        return self.rank
    def getSuit(self):
        return self.suit
    def value(self):
        if self.rank == "Ace":
            val = 1
        if self.rank >10:
            val = 10
        else:
            val = self.rank
        return val
    def __str__(self):
        str = f"{self.list[self.rank-1]} of {self.type[self.suit]}"
        return str
