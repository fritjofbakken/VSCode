def pepLineLength(filename):
    file = open(filename).readlines(filename)
    num = 1
    long = 0
    for line in file:
        line = line.strip("\n")
        if len(line) > 79:
            print(f'line {num} too long: {len(line)}')
            long += 1
        num += 1
        
    print(long,"lines are too long")