def calculate_loan(property_price,loan,interest_rate):
    fee = 0
    if loan > 0.7*property_price:
        amm = (loan*0.02)/12

    elif loan > 0.5*property_price:
        amm = (loan*0.01)/12
    else: amm = 0.0

    inter = ((interest_rate/100)*loan)/12

    tot = amm + inter
    
    print(f"amortization: {amm}\ninterest: {inter}\ntotal: {tot}")