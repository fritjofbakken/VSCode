class SimpleCounter:
  def __init__(self):
    self.num = 9999

  def count(self):
    self.num+=1
    return self.num

  def reset(self):
    self.num = 0

  def getValue(self):
    return self.num

class BoundedCounter(SimpleCounter):
  def __init__(self,init,max):
    self.num = init
    self.max = max

  def count(self):
    if SimpleCounter.count(self) > self.max:
      SimpleCounter.reset(self)
      

class ChainedCounter(BoundedCounter):
  def __init__(self,init,max,next):
    self.num = init
    self.max = max
    self.next = next

  def count(self):
    if SimpleCounter.count(self) > self.max:
      if not self.next == None:
        self.next.count()
      SimpleCounter.reset(self)
      