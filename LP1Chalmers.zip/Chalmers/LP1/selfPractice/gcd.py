def gcd(m,n):
    while True:
        if not n == 0:
            q = m//n
            print(m,n)
            r = m%n
            m = n
            n = r
            print(m,n)
        else:
            gcd = n
            return m
    

