import math

class Ratio:
    def __init__(self, nom, denom):
        self.nom = nom
        self.denom = denom

    def __repr__(self):
        s = f'Ratio({self.nom},{self.denom})'
        return s

    def __add__(self,other):
        nom = other.nom
        denom = other.denom
        gcd = math.gcd(denom, self.denom)

        nom = (nom*self.denom + self.nom*denom)/gcd
        denom = (denom*self.denom)/gcd

        return Ratio(nom , denom)

    def __mul__(self,other):
        nom = other.nom
        denom = other.denom

        gcd = math.gcd(denom, self.denom)

        nom = nom* self.nom
        denom = denom * self.denom

        return Ratio(nom , denom)

    def __eq__(self,other):
        
        if self.nom/self.denom == other.nom/other.denom:
            res = True
        else: 
            res = False
        return res


