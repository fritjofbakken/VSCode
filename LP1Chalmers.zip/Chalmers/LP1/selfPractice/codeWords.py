def code_words(text, dictionary):
    text = text.split()
    new = []
    for word in text:
        if str(word) in dictionary:
            new.append(dictionary[word])
        else:
            new.append(word)

    return(" ".join(new))

