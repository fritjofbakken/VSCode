import math as m
def  circle_area(r):
    area = (r**2)*m.pi
    return area

def circle_circumference(r):
    circ = 2*r*m.pi
    return circ


def cylinder_area(r,h):
    area = (circle_circumference(r)*h)+(circle_area(r)*2)
    return area

print(circle_circumference(1))