class Application:
    def __init__(self, name, personalNum, distance):
        self.name        = name
        self.personalNum = personalNum
        self.distance    = distance
    def getName(self): return self.name
    def getPersonalNumber(self): return self.personalNum
    def distanceFromSchool(self): return self.distance



class ApplicationList:
    def __init__(self, nrOfStudents):
        self.nrOfStudents = nrOfStudents
        self.List = range(nrOfStudents)
        self.accepted = {}
        
    def addApplication(self, app):
        if len(self.List) > 0 and len(self.accepted.keys()) < self.nrOfStudents:
            if app.distanceFromSchool() < 5:
                self.accepted.update({app.getName() : app.getPersonalNumber()})
            
    def printAccepted(self):
        for key,val in self.accepted.items():
            print(key, val)


# def case1():
#     list = ApplicationList(2)
#     list.addApplication(Application('Erik','123',2))
#     list.addApplication(Application('Maria','322',1.5))
#     list.addApplication(Application('Stefan','311',0.5))
#     list.printAccepted()


# print(case1())