class DiceStats:
    def __init__(self):
        self.freq = [0,0,0,0,0,0]
        self.dict = {}
        self.count = 0
        self.part = 1
        
    def addRoll(self, roll):
        if roll in self.dict.keys():
            self.dict[roll] += 1
        else:
            self.dict[roll] = 1
        
    
        self.count +=1
        
        # print(self.count)
    def getFrequencies(self):
        self.part = 1/self.count
        for key, value in self.dict.items():

            self.freq[key-1] = value*self.part
        print(self.freq)

        return self.freq
        
    def isFair(self,epsilon):
        epsilon += 1/6
        self.getFrequencies()
        for i in self.freq:
            if i > epsilon:
                return False
            if i <= epsilon:
                return True
            
# def case2():
#     stats = DiceStats()
#     stats.addRoll(1)
#     stats.addRoll(4)
#     stats.addRoll(6)
#     stats.addRoll(3)
#     stats.addRoll(5)
#     stats.addRoll(2)
#     stats.addRoll(6)
#     stats.addRoll(1)
#     return stats.isFair(0.001)

def case3():
    stats = DiceStats()
    stats.addRoll(1)
    stats.addRoll(4)
    stats.addRoll(6)
    stats.addRoll(3)
    stats.addRoll(5)
    stats.addRoll(2)
    stats.addRoll(6)
    stats.addRoll(1)
    return stats.isFair(0.09)

print(case3())