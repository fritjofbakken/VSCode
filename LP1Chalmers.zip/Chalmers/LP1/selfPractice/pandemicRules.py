def pandemic_rules(numC,totalNum,population):
    capita = totalNum/(population/100000)
    if not capita<numC:
        if capita >= 50:
            return "red"
        if capita >=25:
            return "yellow"
        else:
            return "green"
        
    else:
        return "green"