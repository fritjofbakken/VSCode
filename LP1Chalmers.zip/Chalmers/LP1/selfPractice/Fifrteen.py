import random

class FifteenModel:
    def __init__(self):
        self.list = []
        for x in range(4):
            temp = []
            for y in range(4):
                num = 1+(y)*4+x
                if not num == 16:
                    temp.append(num)
                else: 
                    temp.append(0)
            self.list.append(temp)
    
    def getValue(self,row,col):
        return(self.list[col][row])



    def tryMove(self,row,col):
        # print(self.list[col][row])
        
        for i in range(1,-1,-1):
            print(i)
            # print(self.list[col][row+i])
            if self.list[col+i][row]==0:
                print("hole is in column")
                self.list[col+1][row] = self.list[col][row]
                self.list[col][row] = 0
                break
            if self.list[col][row+i] == 0:
                print("hole is in row")
                self.list[col][row+i] = self.list[col][row]
                self.list[col][row] = 0
                break


    def shuffle(self):
        for i in range(len(self.list[0])):
            random.shuffle(self.list[i])

        return random.shuffle(self.list)




def case4():
    m = FifteenModel()
    m.tryMove(3,2) # must succeed
    m.shuffle()
    print(m.list)
    return (m.getValue(0,0),m.getValue(0,1),m.getValue(0,2),m.getValue(0,3)
           ,m.getValue(1,0),m.getValue(1,1),m.getValue(1,2),m.getValue(1,3)
           ,m.getValue(2,0),m.getValue(2,1),m.getValue(2,2),m.getValue(2,3)
           ,m.getValue(3,0),m.getValue(3,1),m.getValue(3,2),m.getValue(3,3))



case4()