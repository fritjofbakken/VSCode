def caesar(num, string):
    alph = "abcdefghijklmnopqrstuvwxyz"
    string = list(string)
    for i in range(len(string)):
        
        for e in range(len(alph)):
            if string[i] == alph[e]:
                index = e+num
                if index >= len(alph):
                    index = index - len(alph)
               
        string[i] = alph[index]
    string = "".join(string)
    return string

print(caesar(20,'secrdfsabcdefghijkdfgdfglmnopqrstuvwxyzadfsets'))