user = {}


user.update({"hej":"hejjjj"})


user.update({"vaaa":"uhmmm"})


print(len(user.values()))