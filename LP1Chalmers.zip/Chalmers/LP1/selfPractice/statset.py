class StatSet():
    def __init__(self):
        self.nums = []
        self.sum = 0
        self.avrg = 0
        self.sqrA = 0
    def addNumber(self, x):
        self.nums.append(x)
    def mean(self):
        for i in self.nums:
            self.sum += i
            self.sqrA += i**2
        self.avrg = self.sum/len(self.nums)
        self.sqrA = self.sqrA/len(self.nums)
        return self.avrg
    def median(self):
        med = (self.nums[0]+self.nums[-1])/2
        return med
    def stdDev2(self):
        std = self.sqrA -  self.avrg**2
        return std
    def count(self):
        return len(self.nums)
    def min(self):
        return self.nums[0]
    def max(self):
        return self.nums[-1]