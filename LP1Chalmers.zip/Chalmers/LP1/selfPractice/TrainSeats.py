class TrainSeats:
    def __init__(self, nrOfSeats):
        self.List = list(range(nrOfSeats))
        print(self.List)
    def pick(self, seatNum):
        if seatNum in self.List:
            print(f'seat number{seatNum} was booked')
            self.List.remove(seatNum)
            return True
        else:
            print("seat not avalible")
            return False
    def book(self, n):
        count=0
        Booked = []
        if n < len(self.List):
            for num in range(n):
                Booked.append(self.List[0])
                self.List.remove(self.List[0])
                count+=1
                print(count)


            return Booked


# def case4():
#     seats = TrainSeats(10)
#     seats.pick(3)
#     return seats.book(5)

# print(case4())

