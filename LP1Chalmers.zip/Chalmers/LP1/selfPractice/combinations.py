import math as m

def combinations(n,k):
    c = 0
    c = (m.factorial(n) / (m.factorial(k)*m.factorial(n-k)))
    return c