def binarySearch(values, i, j, key):
    x = 0
    while x <20: 
        print(i,j,key,values)
        k = int((i+j)/2)
        if values[k] == key:
            return k

        if key<k:
            j = k-1
        if key>k:
            i = k+1
        
        x+=1
        

binarySearch([1, 5, 7, 8],0,3,5)
    
        




    