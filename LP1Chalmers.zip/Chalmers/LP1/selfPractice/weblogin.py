class User:
    def __init__(self, name, password, email):
        self.name = name
        self.password = password
        self.email = email
    def getName(self): return self.name
    def getPassword(self): return self.password
    def sendMessage(self,message): print(message,"sent to",self.email)


class WebLogin:
    def __init__(self):
        self.store = {}
        
    
    def addUser(self, name, password, email):
        self.store[name] =  {email : password}
        self.email = "".join(self.store[name].keys())
        
    
    def login(self, name, password):
        if name in self.store.keys():
            if password in self.store[name].values():
                print("correct password :-)")
                return True
            else:
                print("incorrect password !!")   
                return False
        else:
            print("No user found with that name")
            return False

            
    def sendPassword(self, name):
        if name in self.store.keys():
            User.sendMessage(self,(f"Your password is: {''.join(self.store[name].values())}")) #join because dictionary


# def case1():
#     wl = WebLogin()
#     wl.addUser('Alice', '123', 'alice@example.com')
#     wl.addUser('Bob', '456', 'bob@example.com')
#     return wl.login('Bob','456')

# def case2():
#     wl = WebLogin()
#     wl.addUser('John', 'x26', 'john@example.com')
#     wl.addUser('Mary', '666', 'mary@example.com')
#     return wl.login('John','666')


# print(case1())