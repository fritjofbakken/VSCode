import random as r



def read_playlist(playlist):
    list = []
    file = open(playlist)
    file = file.readlines()
    for line in file:
        line = line.split("; ")
        line[2] = line[2].strip()
        list.append(line)
        # print(line)

    return list


# print(read_playlist("spellista.txt"))

def the_spotify_shuffle(playlist):
    list = read_playlist(playlist)
    shuffled = [None]*len(list)
    artistCount = {}
    for line in list:
        Artist = line[0]    
        if not Artist in artistCount:
            artistCount.update({Artist : 1})
        else:
            artistCount[Artist] += 1
            
    r.shuffle(list)



        
                
        
        print(shuffled)

    
    # print(shuffled)
    

    
    return shuffled
    
        
the_spotify_shuffle("spellista.txt")