def movieTickets(nrTickets,nrUnder18,time):
    sum = 0
    sum+=(nrUnder18)*50
        
    sum+=(nrTickets-nrUnder18)*100
    if time<18:
        sum=sum*0.9
    return sum