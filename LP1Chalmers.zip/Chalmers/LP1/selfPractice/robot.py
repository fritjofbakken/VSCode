class Robot():
    def __init__(self):
        self.x = 0
        self.y = 0
        self.pos = (self.x,self.y)
        self.dirs = ["NORTH", "WEST", "SOUTH", "EAST"]
        self.dir = self.dirs[0]

    def getPosition(self):
        return self.pos
    
    def getDirection(self):
        return self.dir
    
    def turnLeft(self):
        for i in range(len(self.dirs)):
            if self.dir == self.dirs[i]:
                if self.dirs[i] == self.dirs[3]:
                    self.dir = self.dirs[0]
                    break
                else:
                    self.dir = self.dirs[i+1]
                    break
                
    def turnRight(self):
        for i in range(len(self.dirs)):
            if self.dir == self.dirs[i]:
                if self.dirs[i] == self.dirs[0]:
                    self.dir = self.dirs[3]
                    break
                else:
                    self.dir = self.dirs[i-1]
                    break
                
    def forward(self, n):
        if self.dir == "NORTH":
            self.y += n
        elif self.dir == "SOUTH":
            self.y -= n
        elif self.dir == "WEST":
            self.x -= n
        elif self.dir == "EAST":
            self.x += n

        self.pos = (self.x,self.y)