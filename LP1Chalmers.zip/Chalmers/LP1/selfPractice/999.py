def div9(num):
    num = str(num)
    while len(num)>1:
        sum = 0
        print(num)
        for i in range(len(num)):
            sum += int(num[i])

        num = str(sum)
        
    print(num)
        