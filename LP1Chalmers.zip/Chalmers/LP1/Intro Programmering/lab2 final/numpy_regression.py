
from numpy import *
import matplotlib.pyplot as plt
import sys


def powers(list, start, end):
    matrix = []
    if len(list) > 0:
        for y in list:
            row = []
            for exponent in range(start,end+1):
                row.append(y**exponent)
            matrix.append(row)
    return array(matrix)

data = transpose(loadtxt(sys.argv[1]))

polDeg = int(sys.argv[2])

X = data[0] # Temperature
Y = data[1] # Numbers of chirps/minute

Xp  = powers(X,0,polDeg)
Yp  = powers(Y,1,1)
Xpt = Xp.transpose()

a = matmul(linalg.inv(matmul(Xpt,Xp)),matmul(Xpt,Yp)) # Polynomial Regression
a = a[:,0]

def poly(a,x): # Get y-value from polynomial coefficients a and x-value
    sum = 0
    for i in range(len(a)):
        sum += a[i]*(x**i)
    return sum
        
plt.plot(X,Y,'ro')

X2 = linspace(X[0],X[-1],int((X[-1] - X[0])/0.2))
Y2 = []
for i in X2:
    Y2.append(poly(a, i)) 
plt.plot(X2,Y2)
plt.show()
