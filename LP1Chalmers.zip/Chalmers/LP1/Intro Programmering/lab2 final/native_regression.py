from matrix import *
import matplotlib.pyplot as plt
import sys

data = transpose(loadtxt(sys.argv[1]))

X = data[0] # Teperature
Y = data[1] # Numbers of chirps/minute

Xp  = powers(X,0,1)
Yp  = powers(Y,1,1)
Xpt = transpose(Xp)

[[b],[m]] = matmul(invert(matmul(Xpt,Xp)),matmul(Xpt,Yp))

PNoC = []
for i in X:
    PNoC.append(b + m * i) # PNoC = Predicted Number of Chirps


plt.plot(X,Y, 'ro')
plt.plot(X, PNoC)
plt.show()
