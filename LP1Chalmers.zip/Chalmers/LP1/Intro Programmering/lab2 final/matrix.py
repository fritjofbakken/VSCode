def transpose(table):
    transposed =[]
    if len(table) > 0:
        for x in range(len(table[0])):
            row = []
            for y in range(len(table)):
                row.append(table[y][x])
            transposed.append(row)
    return transposed


def powers(list, start, end):
    matrix = []
    if len(list) > 0:
        for y in list:
            row = []
            for exponent in range(start,end+1):
                row.append(y**exponent)
            matrix.append(row)
    return matrix


def matmul(mat1, mat2):
    resmat = []
    if len(mat2)>0 and len(mat1)>0:
        if (len(mat1[0]) == len(mat2)):
            mat2 = transpose(mat2)
            for z in range(len(mat1)):
                rowmat = []
                for y in range(len(mat2)):
                    sum = 0
                    for x in range(len(mat1[0])):
                        sum += mat1[z][x] * mat2[y][x]
                    rowmat.append(sum)
                resmat.append(rowmat)       
        else:
            print("FatalException: system32 was deleted\nNumber of columns in the first matrix must be equal to number of rows in the second matrix")   
    return resmat


def invert(mat):
    if (len(mat) == 2) and (len(mat[0]) == 2):
        det = mat[0][0]*mat[1][1] - mat[0][1]*mat[1][0]
        
        invmat = [[mat[1][1]/det,-mat[0][1]/det],
                  [-mat[1][0]/det,mat[0][0]/det]]
        return(invmat)        
        

        
    else:
        print(f"{mat}\n{'^'*len(str(mat))}\nSyntaxError: invalid syntax")


def loadtxt(path):
    file = open(path, encoding="utf-8")
    list = []
    for line in file:
        line = line.strip('\n').split("\t")
        for number in range(len(line)):
            line[number] = float(line[number])
        list.append(line)
        
    file.close()
    return list



