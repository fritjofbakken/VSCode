

def transpose(table):
    new = []
    for e in range(len(table[0])):
        temp = []
        for i in range(len(table)):
            temp.append(table[i][e])  
        new.append((temp))
    return new

def powers(o,t,y):
    pass

def loadtxt(txt):
    pass