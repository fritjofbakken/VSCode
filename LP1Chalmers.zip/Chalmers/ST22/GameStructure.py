class game():
    def __init__(self):
        self.matrix = []
        for x in range(3):
            temp = []
            for y in range(3):
                temp.append("")
            self.matrix.append(temp)
        print(self.matrix)
        self.player = ["x","o"]
        self.currentPlayer = self.player[0]


        
    def play(self,row,col):
        while self.gameOver == False:
            if self.matrix[row][col] == "":
                self.matrix[row][col] = self.currentPlayer
                if self.currentPlayer == self.player[0]:
                    self.currentPlayer == self.player[1]
                    self.gameOver()
                else:
                    self.currentPlayer == self.player[1]    
                    self.gameOver()
            else:
                print("invalid choice")


    def gameOver(self):
        for x in range(3):
            if self.matrix[x].count("x") == 3:
                print("play 1 wins")
                break
            elif self.matrix[x].count("o") == 3:
                print("play 2 wins")
                break
            for y in range(3):
                if self.matrix[x][y] == self.matrix[x][y+1] == self.matrix[x][y] == "x":
                    print("play 1 wins")
                    break
                elif self.matrix[x][y].count("o") == 3:
                    print("play 2 wins")
                    break




# game()

lista = [1,2,3,4,5,5]

print(lista.count(1))