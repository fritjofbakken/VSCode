def findMatch(pattern):
    file = open("words.txt").readlines()
    for line in file:
        print(line.strip())


findMatch("hej")