from GameGraphics import *
from GameStructure import *

Game = game()
while True:
    Game.play(2,2)