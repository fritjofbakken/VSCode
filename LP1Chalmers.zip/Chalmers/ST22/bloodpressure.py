def bloodpressure():
    sys = input("write your systolic pressure")
    dia = input("write your diastolic pressure")

    if sys<90 and dia<60:
        print("low pressure")
    elif sys<120 and dia<80:
        print("ideal")
    elif sys<140 and dia<90:
        print("pre-high bloodpressure")
    elif sys <190 and dia<100:
        print("high")
    else:
        print("value out of bounds")
    
