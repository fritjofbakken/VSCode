import pygame

pygame.init()